<?php

namespace App\Controllers;

use App\Libraries\Codex;

class Home extends BaseController
{
    public function index()
    {
        $data['departments'] = Codex::Getdepartments();
        $this->render('index', $data);
    }
}
