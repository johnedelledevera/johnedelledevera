<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->add('dologin', 'BaseController::dologin');
$routes->add('docreate', 'BaseController::docreate');
$routes->add('dobooking', 'BaseController::dobooking');
$routes->add('logout', 'BaseController::logout');
$routes->add('myaccount', 'BaseController::myaccount');
$routes->add('dodelete', 'BaseController::dodelete');