<?php

namespace App\Libraries;

class Codex
{
    public static function Authorization($post) {
        $db = \Config\Database::connect();
        $username = $post['email'];
        $password = $post['password'];

        $sql = "SELECT * FROM users WHERE email = ? AND password = ? ";
        $sth = $db->query($sql, array($username, $password));
        if ($account = $sth->getRow()) {
            $_SESSION['userid'] = md5($account->id);
            return 1;
        } else {
            return 0;
        }
    }

    public static function Createaccount($post) {
        $db = \Config\Database::connect();
        $fullname = $post['fullname'];
        $email = $post['email'];
        $password = $post['password'];

        $builder = $db->table('users');
        $builder->set('fullname', $fullname);
        $builder->set('email', $email);
        $builder->set('password', $password);
        $builder->insert();
        $_SESSION['userid'] = md5($db->insertID());
        return;
    }

    public static function Createappointment($post) {
        $db = \Config\Database::connect();
        $department = $post['department'];
        $fullname = $post['fullname'];
        $email = $post['email'];
        $date = $post['aptdate'];
        $time = $post['apttime'];

        $sql = "SELECT * FROM users ";
        $sth = $db->query($sql);
        $accts = $sth->getResult();
        
        foreach ($accts as $acct) {
            if ($_SESSION['userid'] == md5($acct->id)) {
                $relid = $acct->id;
            }
        }

        $builder = $db->table('appointment');
        $builder->set('relid', $relid);
        $builder->set('name', $fullname);
        $builder->set('dept_id', $department);
        $builder->set('email', $email);
        $builder->set('appt_date', date('Y-m-d', strtotime($date)));
        $builder->set('appt_time', strtotime($time));
        $builder->insert();
        return;
    }
    
    public static function Getdepartments()
    {
        $db = \Config\Database::connect();
        $sql = "SELECT * FROM departments ";
        $sth = $db->query($sql);
        return $sth->getResult();
    }
    
    public static function Getuserinfo()
    {
        $db = \Config\Database::connect();
        
        $sql = "SELECT * FROM users ";
        $sth = $db->query($sql);
        $accts = $sth->getResult();
        
        foreach ($accts as $acct) {
            if ($_SESSION['userid'] == md5($acct->id)) {
                $relid = $acct->id;
            }
        }
        
        $sql = "SELECT * FROM users WHERE id = ? ";
        $sth = $db->query($sql, array($relid));
        return $sth->getRow();
    }
    
    public static function Getappointments()
    {
        $db = \Config\Database::connect();
        
        $sql = "SELECT * FROM users ";
        $sth = $db->query($sql);
        $accts = $sth->getResult();
        
        foreach ($accts as $acct) {
            if ($_SESSION['userid'] == md5($acct->id)) {
                $relid = $acct->id;
            }
        }
        
        $sql = "SELECT appointment.*, departments.name as dept_name FROM appointment ";
        $sql .= "LEFT JOIN departments ON appointment.dept_id = departments.id ";
        $sql .= "WHERE appointment.relid = ? ";
        $sth = $db->query($sql, array($relid));
        return $sth->getResult();
    }
    
    public static function Dodelete($id)
    {
        $db = \Config\Database::connect();
        
        $builder = $db->table('appointment');
        $builder->where('id', $id);
        $builder->delete();
        return;
    }
}