<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Malvar ECare</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="An Online Appointment Scheduling System With Patient Monitoring For Malvar Health Center" name="keywords">
    <meta content="An Online Appointment Scheduling System With Patient Monitoring For Malvar Health Center" name="description">

    <!-- Favicon -->
    <link href="assets/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;700&family=Roboto:wght@400;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo base_url('assets/lib/owlcarousel/assets/owl.carousel.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css') ?>" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet">
    
    <script type="text/javascript">
        var uid = "<?php echo @$_SESSION['userid'] ?>";
    </script>
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid py-2 border-bottom d-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-lg-start mb-2 mb-lg-0">
                    <div class="d-inline-flex align-items-center">
                        <a class="text-decoration-none text-body pe-3" href=""><i class="bi bi-telephone me-2"></i>0927 777 7777</a>
                        <span class="text-body">|</span>
                        <a class="text-decoration-none text-body px-3" href=""><i class="bi bi-envelope me-2"></i>info@malvarecare.com</a>
                    </div>
                </div>
                <div class="col-md-6 text-center text-lg-end">
                    <div class="d-inline-flex align-items-center">
                        <a class="text-body px-2" href="">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a class="text-body px-2" href="">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a class="text-body px-2" href="">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a class="text-body px-2" href="">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a class="text-body ps-2" href="">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid sticky-top bg-white shadow-sm">
        <div class="container">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0">
                <a href="<?php echo base_url('/') ?>" class="navbar-brand">
                    <h1 class="m-0 text-uppercase text-primary"><i class="fa fa-clinic-medical me-2"></i>Malvar ECare</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0">
                        <a href="#" class="nav-item nav-link active">Home</a>
                        <a href="#" class="nav-item nav-link">About</a>
                        <a href="#" class="nav-item nav-link">Service</a>
                        <a href="#" class="nav-item nav-link">Contact</a>
                        <?php if (@$_SESSION['userid']): ?>
                        <a href="myaccount" class="nav-item nav-link">My Account</a>
                        <?php else : ?>
                        <a href="javascript:;" class="nav-item nav-link" data-toggle="modal" data-target="#loginModal">Sign In</a>
                        <a href="javascript:;" class="nav-item nav-link" data-toggle="modal" data-target="#registerModal">Register</a>
                        <?php endif ?>
                        <?php if (@$_SESSION['userid']): ?>
                        <a href="logout" class="nav-item nav-link">Logout</a>
                        <?php endif ?>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->

    <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-bottom-0"></div>
                <div class="modal-body">
                    <div class="form-title text-center mb-3">
                        <h4>Login</h4>
                    </div>
                    <span id="login-alert"></span>
                    <div class="d-flex flex-column text-center">
                        <form id="frmlogin">
                            <div class="form-group mb-3">
                                <input type="email" name="email" class="form-control bg-light border-0" placeholder="Your Email Address" style="height: 55px;" required />
                            </div>
                            <div class="form-group mb-3">
                                <input type="password" name="password" class="form-control bg-light border-0" placeholder="Your Password" style="height: 55px;" required />
                            </div>
                            <div class="form-group mb-3">
                                <input type="checkbox" id="rememberMe"> <label for="rememberMe">Remember Me</label>
                            </div>
                            <button type="submit" id="loginbtn" class="btn btn-info btn-block btn-round">Login</button>
                        </form>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-center">
                    <div class="signup-section">
                        Need help? <a href="#" class="text-info"> Forgot Password</a>.
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="registerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-bottom-0">
                </div>
                <div class="modal-body">
                    <div class="form-title text-center md-3">
                        <h4>Create an Account</h4>
                    </div>
                    <span id="create-alert"></span>
                    <div class="d-flex flex-column text-center">
                        <form id="frmregister">
                            <div class="form-group mb-3">
                                <input type="text" name="fullname" class="form-control bg-light border-0" placeholder="Enter your Full Name" style="height: 55px;" required />
                            </div>
                            <div class="form-group mb-3">
                                <input type="email" name="email" class="form-control bg-light border-0" placeholder="Enter your Email Address..." style="height: 55px;" required />
                            </div>
                            <div class="form-group mb-3">
                                <input type="password" name="password" class="form-control bg-light border-0" placeholder="Enter your password..." style="height: 55px;" required />
                            </div>
                            <div class="form-group mb-3">
                                <input type="password" name="confpass" class="form-control bg-light border-0" placeholder="Confirm your password..." style="height: 55px;" required />
                            </div>
                            <div class="form-group mb-3">
                                <input type="checkbox" id="tos" required /> <label for="tos">I agree with the <a href="javascript:;">Terms of Service</a></label>
                            </div>
                            <button type="submit" id="regbtn" class="btn btn-info btn-block btn-round">Create an Account</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>