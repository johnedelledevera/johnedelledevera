<div class="container-fluid bg-primary my-5 py-5">
    <div class="container py-5">
        <div class="row gx-5 mb-5">
            <div class="col-lg-6 mb-lg-0">
                <div class="mb-4">
                    <h5 class="d-inline-block text-white text-uppercase border-bottom border-5">My Account</h5>
                </div>
            </div>
            <?php if (@$_SESSION['userid']): ?>
            <div class="col-lg-6">
                <div class="bg-white rounded p-5">
                    <form id="frmbookapt">
                        <div class="row g-3">
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Full Name</label>
                                    <input type="text" class="form-control bg-light border-0" style="height: 55px;" value="<?php echo $user->fullname ?>" readonly />
                                </div>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input type="text" class="form-control bg-light border-0" style="height: 55px;" value="<?php echo $user->email ?>" readonly />
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif ?>
        </div>
        <div class="row gx-5">
            <div class="col-lg-6 mb-lg-0">
                <div class="mb-4">
                    <h5 class="d-inline-block text-white text-uppercase border-bottom border-5">My Appointments</h5>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="bg-white rounded p-5">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Full Name</th>
                                <th scope="col">Email Address</th>
                                <th scope="col">Department</th>
                                <th scope="col">Date/Time</th>
                            </tr>
                            <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($apts as $apt): ?>
                            <tr>
                                <td scope="row"><?php echo $apt->name ?></td>
                                <td><?php echo $apt->email ?></td>
                                <td><?php echo $apt->dept_name ?></td>
                                <td><?php echo $apt->appt_date ?> <?php echo date('h:i A', $apt->appt_time) ?></td>
                                <td><button class="btn btn-sm btn-danger dodeleteapt" aptid="<?php echo $apt->id ?>">Cancel</button></td>
                            </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>